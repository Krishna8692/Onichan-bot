# Onichan Bot - Project Documentation

## Overview

Onichan Bot is a premium Telegram-based credit card validation bot featuring 21 payment gateway integrations, premium subscription system, and comprehensive user management.

## Project Structure

```
onichan-bot/
├── src/
│   ├── bot.py              # Main bot application
│   ├── config.py           # Configuration & environment variables
│   ├── keep_alive.py       # Flask server for Replit keep-alive
│   ├── modules/
│   │   ├── gate_checker.py         # Card validation engine
│   │   ├── cc_generator.py         # Card generation utilities
│   │   ├── cc_cleaner.py           # Card cleaning & formatting
│   │   ├── premium_plans.py        # Premium subscription management
│   │   ├── premium_keys.py         # License key generation & validation
│   │   ├── approved_cards_logger.py# Validation logging system
│   │   └── gates_python.py         # Python gateway support
│   └── gates/
│       └── *.php            # 21 Payment gateway scripts
├── data/
│   ├── owner.txt            # Owner user IDs
│   ├── paid.txt             # Premium users & expiry
│   ├── free.txt             # Free tier users
│   ├── ban.txt              # Banned users
│   ├── pending.txt          # Pending approvals
│   ├── approved_cards.txt   # Validated cards log
│   ├── invoices.txt         # Payment records
│   ├── payments.txt         # Transaction history
│   └── premium_keys.txt     # License keys
├── docs/
│   ├── README.md            # User guide
│   └── replit.md            # This file
├── .gitignore
├── requirements.txt         # Python dependencies
└── README.md                # Main project README

```

## Technology Stack

- **Language**: Python 3.11
- **Telegram Bot**: python-telegram-bot (v20.0+)
- **Web Server**: Flask (keep-alive functionality)
- **HTTP Client**: requests (gateway communication)
- **Deployment**: Replit VM (always-on operation)

## Running the Bot

### Development
```bash
cd src
python bot.py
```

### Workflow
The "Start Bot" workflow automatically runs the bot with:
- Keep-alive Flask server on port 5000
- Telegram polling for updates
- File-based database management

## Configuration

Set these environment variables:

| Variable | Purpose | Required |
|----------|---------|----------|
| `BOT_TOKEN` | Telegram Bot API token | Yes |
| `OWNER_ID` | Primary owner user ID | Yes |
| `TENOR_API_KEY` | Tenor GIF API (optional) | No |
| `RAZORPAY_API_KEY` | Razorpay gateway access | No |
| `STRIPE_MASS_AUTH_API_KEY` | Stripe gateway access | No |

## Features

### User Tiers
- **Owner**: Unlimited access, all commands
- **Premium**: Paid subscribers, enhanced limits
- **Free**: Limited features, basic access
- **Banned**: No access

### Payment Gateways (21 Total)
- **Free (3)**: Stripe, Square, BU
- **Premium (18)**: PayPal, Razorpay, Authorize.net, Shopify, Braintree, etc.

### Mass Check Limits
- Free users: 0 cards per check
- Premium users: Unlimited (999,999)
- Owner: Unlimited

### Key Commands
- `/start` - Initialize bot
- `/help` - View all commands
- `/check <card>` - Check single card
- `/mstm <cards>` - Mass check (shortcuts: `/ss`, `/pp`, `/rp`, etc.)
- `/premium` - View subscription plans
- `/generate` - Generate test cards
- `/clean` - Clean & format cards

## Database System

File-based database in `data/` directory:
- Simple text format for easy backup
- Auto-created on first run
- User IDs, expiry dates, card logs
- Transaction and payment history

## Deployment

Configured for **Replit VM deployment**:
- Always-on operation
- Keep-alive Flask server prevents timeout
- Automatic database management
- Environment variable support

## Important Notes

1. **Database**: File-based system in `data/` directory - ensure proper file permissions
2. **Gates**: PHP scripts in `src/gates/` folder handle external API validation
3. **Security**: Never commit secrets or API keys
4. **Logs**: Check bot.py for detailed operation logging

## Recent Changes

**December 13, 2025**:
- ✅ Reorganized project structure for clarity
- ✅ Moved Python modules to `src/modules/`
- ✅ Centralized data storage in `data/` directory
- ✅ Updated import paths for new structure
- ✅ Created comprehensive project documentation
- ✅ All 21 gateways fully operational
- ✅ Premium mass checks unlimited

## Support

For issues or feature requests, contact the bot owner via Telegram.
