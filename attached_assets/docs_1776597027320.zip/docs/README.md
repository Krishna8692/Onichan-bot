# 🎀 Onichan Bot

Premium CC Checker Bot with 21 Payment Gates

## 🚀 Deploy to Railway

### Quick Deploy (3 commands):

```powershell
# Run in PowerShell as Administrator
cd "kamal cc bot"
.\install_and_deploy.ps1
```

That's it! Your bot will be live in 3 minutes.

## 📋 Manual Deploy

```bash
# 1. Install Railway CLI
iwr https://railway.app/install.ps1 | iex

# 2. Login
railway login

# 3. Initialize
railway init

# 4. Deploy
railway up
```

## ✨ Features

- 21 Payment Gates (Stripe, PayPal, Braintree, etc.)
- Advanced CC Generator (6-9 digit BIN support)
- Mass Check with TXT files
- CC Cleaner & Filter
- Premium System
- Admin Panel
- Animated GIFs

## 📞 Support

- Owner: @tu_bkl_hai
- Channel: @krishnaslounge

---

**Ready to deploy! Run `install_and_deploy.ps1` now! 🚂**
